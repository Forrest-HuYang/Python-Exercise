from pyecharts import options as opts
from pyecharts.charts import Bar
from django.http import HttpResponse
from django import template
from django.shortcuts import render
from random import randrange
import base64
from datetime import datetime
import requests
import json
import time
from PIL import Image


# Create your views here.
from io import BytesIO
from django.core.files.base import ContentFile
from django.core.files.uploadedfile import InMemoryUploadedFile


def pil_loadimage(image_io):
    im = Image.open(image_io)
    # ltrb_border = (0, 0, 0, 10)
    # im_with_border = ImageOps.expand(im, border=ltrb_border, fill='white')

    # img_in_memory = StringIO()
    # fig.savefig(img_in_memory, format="png")  # dunno if your library can do that.
    # context['image'] = base64.b64encode(img_in_memory.getvalue())

    buffer = BytesIO()
    # im_with_border.save(fp=buffer, format='PNG')
    im.save(fp=buffer, format='PNG')
    buff_val = buffer.getvalue()
    # return ContentFile(buff_val)
    return buffer


def retrieve_alldata():
    url = 'https://view.inews.qq.com/g2/getOnsInfo?name=disease_h5'

    mydata = json.loads(requests.get(url=url).json()['data'])
    for item in mydata:
        print(item)
        # print(mydata[item])

    return mydata


def index(request):
    """View function for home page of site."""

    mydata = retrieve_alldata()

    context = {}
    for item in mydata:
        context[item] = mydata[item]

    pillow_image_buffer = pil_loadimage(
        './ncov2019app/static/images/2019-nCoV疫情地图.png')
    # image_file = InMemoryUploadedFile(
    #    pillow_image, None, '2019-nCoV疫情地图.png', 'image/png', pillow_image.tell, None)
    # really need rewrite img in POST for success form validation
    request.FILES['map_image'] = base64.b64encode(
        pillow_image_buffer.getvalue())
    context['map_image'] = base64.b64encode(pillow_image_buffer.getvalue())
    # Render the HTML template index.html with the data in the context variable
    return render(request, 'index.html', context=context)


def daily_increase(request):
    context = {}
    return render(request, 'daily_increase.html', context=context)


def area_detail_map(request):
    context = {}
    print(request.GET)
    return render(request, 'area_detail_map.html', context=context)


def daily_total(request):

    mytemplate = template.loader.get_template('daily_total.html')
    bar = (
        Bar()
        .add_xaxis(["衬衫", "羊毛衫", "雪纺衫", "裤子", "高跟鞋", "袜子"])
        .add_yaxis("商家A", [5, 20, 36, 10, 75, 90])
        .add_yaxis("商家B", [15, 25, 16, 55, 48, 8])
        .set_global_opts(title_opts=opts.TitleOpts(title="Bar-基本示例", subtitle="我是副标题"))
    )
    bar.add_js_funcs("""
        chart_%s.on('click', function (param) {
            if (isNaN(param.name.charAt(0))){
                var host =  window.location.protocol + '//' + window.location.hostname + ':' + window.location.port;
                new_url = host+"/ncov2019app/area_detail_map/?area_id="+param.name;
                console.log(param.name);

                //open up an window
                //window.open(new_url, param, "width=1280,height=1024");
    
                // Open a URL in a lightbox
                //var lightbox = lity('//www.youtube.com/watch?v=XSGBVzeBUbk');
                var lightbox = lity(new_url);
                // Bind as an event handler
                //lightbox.on('click', '[data-lightbox]', lity);

                lightbox.on_click()   
            }

        });""" % bar.chart_id)

    print(bar.chart_id)

    context = dict(myechart=bar.render_embed(), )  # 图表数据

    return HttpResponse(mytemplate.render(context, request))
    # return HttpResponse(c.render_embed())
    # return render(request, 'daily_total.html', context=context)
