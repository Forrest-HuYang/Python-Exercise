from django.apps import AppConfig


class Ncov2019AppConfig(AppConfig):
    name = 'ncov2019app'
